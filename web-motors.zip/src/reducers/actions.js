export const INITIAL_STATE = {
	car: false,
	moto: false,
	local: ``,
	range: `Todos`,
	brand: `Todos`,
	model: `Todos`,
	year: `Todos`,
	price: `Todos`,
	version: `Todos`,
};

export const SET_DATA = `SET_DATA`;
export const CLEAR_DATA = `CLEAR_DATA`;
