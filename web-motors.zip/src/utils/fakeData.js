export const range = [
	{ ID: `10km`, Name: `10km` },
	{ ID: `20km`, Name: `20km` },
	{ ID: `50km`, Name: `50km` },
	{ ID: `100km`, Name: `100km` },
];

export const years = [
	{ ID: 2020, Name: 2020 },
	{ ID: 2019, Name: 2019 },
	{ ID: 2018, Name: 2018 },
	{ ID: 2017, Name: 2017 },
	{ ID: 2016, Name: 2016 },
	{ ID: 2015, Name: 2015 },
	{ ID: 2014, Name: 2014 },
	{ ID: 2013, Name: 2013 },
	{ ID: 2012, Name: 2012 },
	{ ID: 2011, Name: 2011 },
];

export const prices = [
	{ ID: `5.000 a 10.000`, Name: `5.000 a 10.000` },
	{ ID: `10.000 a 20.000`, Name: `10.000 a 20.000` },
	{ ID: `20.000 a 30.000`, Name: `20.000 a 30.000` },
	{ ID: `30.000 a 40.000`, Name: `30.000 a 40.000` },
	{ ID: `40.000 a 50.000`, Name: `40.000 a 50.000` },
];
